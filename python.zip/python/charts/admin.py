from django.contrib import admin

from .models import AccountInfo

admin.site.register(AccountInfo)
